#!/bin/sh

CMD="/etc/acm_module/acm_gadget.sh"

case "$1" in
    start)
        $CMD &
        ;;
    stop)
        ;;
    *)
        echo "Usage : $0 {start}"
esac
