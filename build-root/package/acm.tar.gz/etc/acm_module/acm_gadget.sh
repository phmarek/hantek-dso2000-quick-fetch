#!/bin/sh

CONFIGFS="/sys/kernel/config"
GADGET="$CONFIGFS/usb_gadget"
MOD_PATH="/etc/acm_module"
FUNC="acm.0"

mount -t configfs none $CONFIGFS
mkdir -p $GADGET
mkdir -p $GADGET/g1
cd $GADGET/g1

insmod $MOD_PATH/u_serial.ko
insmod $MOD_PATH/usb_f_acm.ko

mkdir -p functions/$FUNC
mkdir configs/c.1
ln -s functions/$FUNC configs/c.1

# Now let Phoenix do the rest of the USB config
# We can't do this after Phoenix already started, will break USB mode switch 
